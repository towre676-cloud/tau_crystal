# Privacy Policy
Tau Crystal does not collect, store, or sell personal data. The app reads GitHub workflow metadata and artifact names in order to publish a PR status check. No data is persisted outside GitHub. For questions, open an issue at https://github.com/towre676-cloud/tau_crystal/issues/new/choose.
