# Discovery scripts

Zero-hunt in a local grid around the current best.

```bash
# 30-second smoke test
./scripts/langlands/discovery_scan.sh
```

Outputs artefacts under `.tau_ledger/` (receipts) and `analysis/` (TSVs).  
See `docs/monographs/langlands_lab.md` for the math.
