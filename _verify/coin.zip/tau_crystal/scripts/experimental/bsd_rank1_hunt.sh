#!/usr/bin/env bash
set -Eeuo pipefail; set +H; umask 022
python scripts/experimental/bsd_rank1.py
