#!/usr/bin/env bash
set -Eeuo pipefail; set +H; umask 022
python scripts/experimental/iwasawa_mu.py
