# Policy gates

Templates for gate/policy checks.

```bash
# 30-second smoke test
bash scripts/gates/check.sh
```

Outputs artefacts under `.tau_ledger/` (receipts) and `analysis/` (TSVs).  
See `docs/monographs/langlands_lab.md` for the math.
