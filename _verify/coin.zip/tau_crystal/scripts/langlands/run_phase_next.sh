bash scripts/langlands/discovery_scan.sh || echo "[discovery] no new record"
