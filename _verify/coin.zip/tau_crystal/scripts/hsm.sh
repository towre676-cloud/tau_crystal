#!/usr/bin/env bash
# Placeholder for HSM integration
echo "[info] HSM support not yet implemented"
