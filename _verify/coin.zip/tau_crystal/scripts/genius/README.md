# Genius toy-models

Playground models with receipts.

```bash
# 30-second smoke test
bash scripts/genius/run.sh
```

Outputs artefacts under `.tau_ledger/` (receipts) and `analysis/` (TSVs).  
See `docs/monographs/langlands_lab.md` for the math.
