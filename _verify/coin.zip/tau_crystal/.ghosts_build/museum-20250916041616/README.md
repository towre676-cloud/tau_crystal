# τ-Crystal Ghost Archive (curated)

Reconstructed byte-for-byte from the last commit touching each path listed in
`analysis/forensics/ghosts.tsv` of the main repo. Museum only; do not merge.

See `.archive/restored.tsv` for files+source SHAs and `.archive/missing.tsv` for unrecoverable paths.
