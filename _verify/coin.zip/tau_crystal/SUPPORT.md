# Support

Questions: open a Q&A in Discussions.  
Bugs: open an Issue with a minimal repro plus `lean --version` and `lake --version`.  
Security: use GitHub Security Advisories (private) instead of public issues.  
We don’t offer paid support yet; Marketplace plans affect CI verification limits only.
