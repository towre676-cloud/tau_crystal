---
layout: post
title: "Dummy’s User Guide"
date: 2025-09-17
---

Dummy’s User Guide published — start on a blank laptop, end with a verified, citable witness pack.

- Ledger: [.tau_ledger/chain/CHAIN](.tau_ledger/chain/CHAIN)
