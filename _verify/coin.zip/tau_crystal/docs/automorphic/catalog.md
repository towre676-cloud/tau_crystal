# Automorphic Catalog

_updated: 2025-09-15T08:58:35.291713Z_

| seed | τ-length |
|---:|---:|
| 15537 | 32 |
| 9220 | 32 |
