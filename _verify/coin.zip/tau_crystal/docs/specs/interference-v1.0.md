# τ‑Crystal interference map v1.0
Encodes overlaps and divergence among key receipts using a deterministic SVG heatmap. Each row = CHAIN, timefold, entropy, etc. Each column = stable hash slot. Manifest stamps the SVG hash.

