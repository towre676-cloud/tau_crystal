# τ-Crystal bin v1.0
Lightweight bash-based receipt verifier for Windows/Linux, simulating a static binary. Verifies receipt schema and hash, stamps results into manifest.
