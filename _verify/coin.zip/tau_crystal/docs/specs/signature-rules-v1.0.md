# τ-Crystal signature_rules v1.0
Defines a constraints dialect (e.g., mathlib_version, proof_style) in constraints.d/*.rules. Builds JSON with rule file hashes, verifies integrity, and stamps into manifest.
