# τ-Crystal physics v1.0
Captures simulation state (residuals, delta27 metrics) in JSON, verifies symmetry and delta bounds, stamps hash into manifest. Supports fracture mode recovery (e.g., agentic flow).
