# τ-Stamp v1.0
Browser extension to fetch latest receipt from .tau_ledger/receipts/, display its hash, and stamp it into docs/manifest.md. Supports user-side verification of τ-Crystal manifests.
