# τ-Crystal mirror v1.0
Fetches and verifies receipts from a remote τ-Crystal repo, stamps metadata into local manifest. Enables gossip-based federated receipt sharing for cross-repo verification.
