# Terms of Service
Tau Crystal is provided “as is,” without warranties or guarantees. Use at your own risk. The app reads workflow run metadata and artifacts to publish a PR check. You are responsible for your CI configuration and uploaded artifacts. For support, use the project’s Issues page.
