# Code of Conduct

We follow the spirit of the Contributor Covenant (v2.1).
Be respectful; no harassment; assume good intent. Report issues to the maintainer via SECURITY.md contact.
