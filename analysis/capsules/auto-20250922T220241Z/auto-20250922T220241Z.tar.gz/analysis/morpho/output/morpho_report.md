# Morphometric Receipt (basic)
- timestamp: 2025-09-19T05:25:10Z
- frontal:  sha256=26c98f9eeefa8c45a1c6429e20e73c2dc4733f304d8b4df1c9a81015e79ae06b  bytes=470504  dims=unknown
- left:     sha256=4578d57633d50c6736dfe2cc3212c0d9db5c34d87596b3a517e04b41429869e2  bytes=479592  dims=unknown
- right:    sha256=860f8372767412623da48666c94c62afe2fe9d43443fad167e5bd81b5b1e1035  bytes=423512  dims=unknown
- FACE.txt sha256=6b110c1f278f8a93c3cdd389a34137ad640fbf72a390af1a2dc49720d1b1a0be
- face2.txt sha256=ebd97b0206d8c7d8f1acdbd060dac54ba492d4a652ad18fe1fec9146a1edc4c3

