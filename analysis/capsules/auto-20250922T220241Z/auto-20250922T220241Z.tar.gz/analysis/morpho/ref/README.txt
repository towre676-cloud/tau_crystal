Place paths to your landmark TSVs in datasets.registry.tsv (col 4).
Each TSV row: id \t x1 \t y1 \t z1 \t x2 \t y2 \t z2 ... (3D, same order per row).
If a dataset has >68 points, include all available; we will normalize and combine.
No images needed. Only landmarks. Licenses must be respected.
