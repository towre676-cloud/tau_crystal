# Gallery (rendered artefacts)

These files are copies of the latest CI artefacts for web viewing.

- `tau_tanh_demo.png`
- `interference.svg`
- `qr-witness.svg`
