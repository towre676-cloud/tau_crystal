# Canonical SHA and Merkle Notes
(placeholder) CI validates/updates this as proofs land.
