# τ‑Crystal policy_gate v1.0
Runs available verifiers and stamps status + report sha into the manifest.
