# τ-Crystal perma_receipt v1.0
Pins JSON receipts to IPFS, retrieves Content Identifier (CID), and stamps into manifest. Verifies integrity via IPFS gateway fetch. Ensures long-term, tamper-proof archival.
