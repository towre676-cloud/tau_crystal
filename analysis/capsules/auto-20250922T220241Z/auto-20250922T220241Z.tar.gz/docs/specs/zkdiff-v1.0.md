# τ-Crystal zkdiff v1.0
Zero-knowledge proof of limited changes between commits. Captures baseline file hashes, proves only claimed files changed, verifies ladder hash without revealing full contents. Stamps manifest with proof metadata.
