# τ-Crystal evolver v1.0
Auto-tunes build parameters (e.g., opt_level, cache_size) using a genetic algorithm, based on cache logs. Stamps evolved parameters into manifest for verification.
