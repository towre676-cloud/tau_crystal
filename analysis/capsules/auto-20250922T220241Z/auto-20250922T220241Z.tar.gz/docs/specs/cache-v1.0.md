# τ-Crystal cache v1.0
Logs Mathlib build metrics (commit, build time, cache hit rate) and predicts optimal cache subset using RL. Stamps log hash into manifest for verification.
