# τ‑Crystal entropy v1.0

Witness records chain size, gzip-compressibility (as a per‑mille proxy for redundancy), head_change tag for last two CHAIN entries, and total bytes of timefold archives. A JSON witness + sha256 is produced; the manifest stamps the sha for audit.
