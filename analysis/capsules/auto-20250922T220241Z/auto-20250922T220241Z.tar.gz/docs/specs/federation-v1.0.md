# τ‑Crystal federation v1.0
Federated dependencies are receipts from other builds. The manifest includes their id, source URL, and verified sha256. Verification ensures no tampering. Useful for cross-repo attestations, bundle inclusion, or remote anchors.

