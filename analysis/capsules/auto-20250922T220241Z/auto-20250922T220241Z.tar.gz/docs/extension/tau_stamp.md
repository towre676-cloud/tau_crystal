# τ-Stamp Browser Extension
A Chrome extension to fetch the latest τ-Crystal receipt and stamp its hash into the manifest.
## Usage
1. Load `extension/tau_stamp/` as an unpacked extension in Chrome (Developer Mode).
2. Click the extension icon to view the latest receipt and stamp the manifest.
